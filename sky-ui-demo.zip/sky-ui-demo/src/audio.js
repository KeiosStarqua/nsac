/* Microphone session. Audio remains local; demo does not upload or transcribe speech. */
(() => {
  const Sky = window.Sky ||= {};
  class VoiceSession {
    constructor(onPhase){this.phase='idle';this.onPhase=onPhase;this.stream=null;this.context=null;this.analyser=null;this.samples=null;this.energy=0;this.pending=false;}
    setPhase(phase){this.phase=phase;this.onPhase(phase);}
    async toggle(){if(this.phase==='listening'){await this.stop();return;}if(this.pending)return;this.pending=true;this.setPhase('requesting_permission');
      try{
        if(!navigator.mediaDevices?.getUserMedia)throw Error('Microphone API unavailable. Use localhost or HTTPS and a supported browser.');
        const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true},video:false});this.stream=stream;
        if(this.phase!=='requesting_permission'){stream.getTracks().forEach(t=>t.stop());return;}
        const Ctx=window.AudioContext||window.webkitAudioContext;if(!Ctx)throw Error('Web Audio not supported.');
        this.context=new Ctx();this.analyser=this.context.createAnalyser();this.analyser.fftSize=512;this.analyser.smoothingTimeConstant=.6;this.samples=new Uint8Array(this.analyser.fftSize);const source=this.context.createMediaStreamSource(stream);source.connect(this.analyser);
        stream.getAudioTracks()[0].onended=()=>{if(this.phase==='listening')this.stop();};this.setPhase('listening');
      }catch(err){this.errorMessage=err?.message||'Microphone permission denied';await this.stop(false);this.setPhase('error');}
      finally{this.pending=false;}
    }
    readEnergy(){if(this.phase!=='listening'||!this.analyser)return 0;this.analyser.getByteTimeDomainData(this.samples);let sum=0;for(let i=0;i<this.samples.length;i++){const n=(this.samples[i]-128)/128;sum+=n*n;}const rms=Math.sqrt(sum/this.samples.length);this.energy+=(Math.min(rms*6,1)-this.energy)*.24;return this.energy;}
    async stop(reset=true){this.stream?.getTracks().forEach(t=>t.stop());this.stream=null;this.analyser=null;this.samples=null;this.energy=0;if(this.context){await this.context.close().catch(()=>{});this.context=null;}if(reset)this.setPhase('idle');}
  }
  Sky.VoiceSession=VoiceSession;
})();
