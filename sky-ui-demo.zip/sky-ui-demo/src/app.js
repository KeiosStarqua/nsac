/* SKY demo coordinator. Fixture health values are demonstration data, not medical assessment. */
(() => {
  const $=(id)=>document.getElementById(id), app=$('skyApp');
  $('spaceArt').innerHTML=window.Sky.createSpaceArt();
  let orb=null;try{orb=new window.Sky.OrbRenderer($('orbCanvas'));}catch(e){console.warn('Orb using CSS fallback:',e.message);$('orbCanvas').hidden=true;}
  const vitals={
    heartRate:{title:'Heart rate',value:'62 bpm',message:'Illustrative resting heart-rate reading. Source: screenshot fixture. No live sensor connected.'},
    respiration:{title:'Respiration',value:'16 br/min',message:'Illustrative breathing-rate reading. Connect a validated sensor for live monitoring.'},
    spo2:{title:'Oxygen saturation',value:'98 %',message:'Illustrative SpO₂ reading from the design reference. This is not an actual oxygen measurement.'},
    sleep:{title:'Sleep duration',value:'7 h 42 m',message:'Illustrative sleep-duration summary. No sleep tracking service is connected.'}
  };
  const phaseText={idle:'Just talk to me...',requesting_permission:'Requesting microphone access…',listening:'Listening… Tap to stop',thinking:'SKY is processing…',speaking:'SKY is speaking…',error:'Mic unavailable — type instead'};
  let previousFocus=null;
  const session=new window.Sky.VoiceSession((phase)=>{
    app.dataset.phase=phase;$('voiceHint').textContent=phaseText[phase]||'Just talk to me...';
    $('micButton').setAttribute('aria-label',phase==='listening'?'Stop microphone capture':phase==='requesting_permission'?'Requesting microphone permission':'Activate microphone');
    $('micButton').disabled=phase==='requesting_permission';
    $('captions').textContent=phase==='listening'?'Microphone active · audio analyzed locally':phase==='error'?(session.errorMessage||'Microphone unavailable'):'';
    $('announcer').textContent=$('voiceHint').textContent;
  });
  function openDetail({title,value='',message,eyebrow='SIMULATED DATA',footer='Demonstration only · Not medical advice'}){
    previousFocus=document.activeElement;$('detailTitle').textContent=title;$('detailValue').textContent=value;$('detailMessage').textContent=message;$('detailEyebrow').textContent=eyebrow;$('detailFooter').textContent=footer;
    $('detailOverlay').hidden=false;document.querySelector('.detail-glass').focus();
  }
  function closeDetail(){$('detailOverlay').hidden=true;previousFocus?.focus();}
  document.querySelectorAll('[data-kind]').forEach(el=>el.addEventListener('click',()=>openDetail(vitals[el.dataset.kind])));
  $('healthButton').addEventListener('click',()=>openDetail({title:'Overall wellness',value:'Stable (demo)',message:'This status reproduces the reference artwork. It is not a clinical finding and is not computed from these four sample metrics.',eyebrow:'REFERENCE SCREEN FIXTURE'}));
  $('hologramButton').addEventListener('click',()=>openDetail({title:'Body hologram',value:'Illustrative scan',message:'The anatomical figure is a decorative projection. No body-region diagnosis or sensor map is connected.',eyebrow:'VISUAL MODEL'}));
  $('missionButton').addEventListener('click',()=>openDetail({title:'Mission context',value:'ISS · Day 170',message:'Mission identifier and day are copied from the concept design. No actual ISS tracking, spacecraft connection or time synchronization is available.',eyebrow:'REFERENCE MISSION'}));
  $('homeButton').addEventListener('click',()=>{closeDetail();$('chatForm').hidden=true;$('greeting').textContent='Good morning, Minh.';$('prompt').textContent='How are you feeling today?';});
  $('detailClose').addEventListener('click',closeDetail);
  $('detailOverlay').addEventListener('click',event=>{if(event.target===$('detailOverlay'))closeDetail();});
  $('micButton').addEventListener('click',()=>session.toggle());
  $('textButton').addEventListener('click',()=>{$('chatForm').hidden=false;$('chatInput').focus();});
  $('chatClose').addEventListener('click',()=>{$('chatForm').hidden=true;$('textButton').focus();});
  $('chatForm').addEventListener('submit',(e)=>{e.preventDefault();const query=$('chatInput').value.trim();if(!query)return;
    $('greeting').textContent='I hear you, Minh.';
    $('prompt').textContent=/sleep|tired|rest/i.test(query)?'Recovery is important. How did you sleep?':/oxygen|heart|pulse|health/i.test(query)?'The readings shown here are sample data only.':'Your message is received in this local UI demo.';
    $('chatInput').value='';$('chatForm').hidden=true;$('announcer').textContent='Local demo response displayed.';
  });
  window.addEventListener('keydown',(e)=>{if(e.key==='Escape'){if(!$('detailOverlay').hidden)closeDetail();else if(!$('chatForm').hidden){$('chatForm').hidden=true;$('textButton').focus();}}});
  window.addEventListener('pagehide',()=>session.stop());
  let last=0,elapsed=0,energy=0;
  function frame(now){if(document.hidden){requestAnimationFrame(frame);return;}if(now-last<33){requestAnimationFrame(frame);return;}const delta=last?Math.min((now-last)/1000,.06):.033;last=now;elapsed+=delta;
    const active=session.phase==='listening';energy=active?session.readEnergy():energy*.92;
    orb?.update(delta,energy,session.phase);
    const wave=makeWave(elapsed,active?energy:.08,session.phase);
    $('wavePath').setAttribute('d',wave);$('waveGlowPath').setAttribute('d',wave);
    requestAnimationFrame(frame);
  }
  function makeWave(time,loudness,phase){const center=35,n=150;let str='';const amp=phase==='listening'?Math.min(loudness*47,28):phase==='thinking'?13:10;
    for(let i=0;i<=n;i++){const x=i*310/n,dist=Math.abs(x-155)/155,envelope=Math.exp(-Math.pow(dist*5.2,2));
      const pulse=Math.sin((x-155)/12-time*3.5)*Math.cos((x-155)/19+time*1.1);
      const rest=Math.sin((x-155)*.16-time*1.7)*Math.exp(-Math.pow((x-155)/30,2));
      const y=center-(phase==='listening'?pulse*amp*envelope:rest*amp*1.2);
      str+=(i?'L':'M')+x.toFixed(1)+','+y.toFixed(1)+' ';
    }return str;
  }
  requestAnimationFrame(frame);
})();
