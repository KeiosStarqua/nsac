/* WebGL 1-compatible transparent procedural orb. Uses no dependencies. */
(() => {
  const Sky = window.Sky ||= {};
  const vertex = `attribute vec2 p; varying vec2 v; void main(){v=p;gl_Position=vec4(p,0.,1.);}`;
  const fragment = `precision highp float;
  varying vec2 v;
  uniform float uTime, uEnergy, uMode;
  float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453123);}
  float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x),mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x),f.y);}
  float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<5;i++){v+=a*noise(p);p=p*2.03+13.7;a*=.5;}return v;}
  void main(){
    vec2 p=v*1.05;float r=length(p),t=uTime*(.24+uMode*.11);float angle=atan(p.y,p.x);
    vec2 q=p+vec2(.075*sin(t*.6),.06*cos(t*.51));
    float war=fbm(q*4.1+vec2(t,-t*.4));
    float inner = .33+.15*sin(angle*3.5+t*2.+war*6.)+.10*sin(angle*7.-t*.7);
    float ringA=exp(-pow((r-(.78+.075*sin(angle*2.1+t*.7+war*2.)))*24.,2.));
    float ringB=exp(-pow((r-(.61+.18*sin(angle*2.5-t*.68)+.05*war))*21.,2.));
    float ringC=exp(-pow((r-(.43+.29*sin(angle*1.4+t*.5+war)))*22.,2.));
    float filament=exp(-pow((p.y-(.31*sin(2.7*p.x+t+war*3.)-.15*cos(p.x*5.-t*.55)))*17.,2.));
    float filament2=exp(-pow((p.x-(.30*sin(2.9*p.y-t*.8)+.2*cos(p.y*4.+t*.4)))*14.,2.));
    float shell=1.-smoothstep(.76,.98,r);float fresnel=pow(clamp(r/.97,0.,1.),5.);
    float irregular=fbm(p*3.3+vec2(t*.3,t*.13));
    vec3 deep=vec3(.02,.12,.34);
    vec3 cyan=vec3(.22,.93,1.);
    vec3 blue=vec3(.17,.53,1.);
    vec3 lilac=vec3(.76,.54,1.);
    vec3 col=mix(deep,blue,.34+.22*war);
    col+=cyan*ringA*1.15+blue*ringB*.95+lilac*ringC*.92;
    col+=cyan*filament*.48+mix(cyan,lilac,.5+.5*sin(angle*2.+t))*filament2*.52;
    col+=mix(blue,lilac,smoothstep(-.2,.9,p.x))*fresnel*(.42+.43*irregular);
    col+=vec3(1.,.70,.5)*exp(-length(p-vec2(.49,-.34))*8.)*.47;
    col+=vec3(.32,.95,1.)*exp(-length(p-vec2(-.25,-.77))*8.)*.31;
    col*=.81+uEnergy*.34;
    float rim=exp(-pow((r-.9)*15.,2.));col+=mix(cyan,lilac,smoothstep(-.7,.75,p.x)) *rim*.56;
    float halo=exp(-pow((r-1.)*8.,2.))*.15+exp(-r*r*6.)*.035;
    float alpha=shell*(.37+.18*war+ringA*.45+ringB*.25+ringC*.27+filament*.22)+rim*.43+halo;
    alpha*=1.-smoothstep(.97,1.22,r);
    vec3 glow=col+vec3(.13,.27,.52)*halo;
    gl_FragColor=vec4(glow,clamp(alpha,0.,1.));
  }`;
  function compile(gl,type,source){const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;}
  class OrbRenderer {
    constructor(canvas){this.canvas=canvas;this.time=0;this.energy=0;this.phase='idle';this.reducedMotion=matchMedia('(prefers-reduced-motion: reduce)').matches;
      this.gl=canvas.getContext('webgl',{alpha:true,antialias:true,premultipliedAlpha:false,preserveDrawingBuffer:false});if(!this.gl)throw Error('WebGL unavailable');
      const gl=this.gl,prog=gl.createProgram();gl.attachShader(prog,compile(gl,gl.VERTEX_SHADER,vertex));gl.attachShader(prog,compile(gl,gl.FRAGMENT_SHADER,fragment));gl.linkProgram(prog);if(!gl.getProgramParameter(prog,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(prog));this.program=prog;gl.useProgram(prog);
      const buf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),gl.STATIC_DRAW);const loc=gl.getAttribLocation(prog,'p');gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,2,gl.FLOAT,false,0,0);
      this.uniforms={time:gl.getUniformLocation(prog,'uTime'),energy:gl.getUniformLocation(prog,'uEnergy'),mode:gl.getUniformLocation(prog,'uMode')};gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);this.render();
    }
    render(){const gl=this.gl,canvas=this.canvas;const quality=Math.min(devicePixelRatio||1,1.5),w=Math.round(canvas.clientWidth*quality),h=Math.round(canvas.clientHeight*quality);if(w<1||h<1)return;if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;gl.viewport(0,0,w,h);}gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT);gl.useProgram(this.program);gl.uniform1f(this.uniforms.time,this.time);gl.uniform1f(this.uniforms.energy,this.energy);gl.uniform1f(this.uniforms.mode, this.phase==='thinking'?1.3:this.phase==='listening'?1:this.phase==='speaking'?1.4:.2);gl.drawArrays(gl.TRIANGLES,0,6);}
    update(delta,energy,phase){this.phase=phase;this.energy+=(energy-this.energy)*.13;if(!this.reducedMotion)this.time+=Math.min(delta,.06);this.render();}
  }
  Sky.OrbRenderer=OrbRenderer;
})();
