# SKY · Astronaut Wellness AI — standalone front-end demo

An original, working recreation of the visual composition in the supplied reference image. It uses SVG, CSS, DOM, browser WebGL shaders and local Web Audio API. There are **no npm packages, CDNs, fonts, image downloads, or remote requests**.

## Easiest: copy one file

Open `SKY_SINGLE_FILE.html` in Chromium or Firefox. The SVG/CSS/WebGL interface renders offline. To use microphone permission, serve it over `http://localhost` (or HTTPS), because browser security can restrict capture from a `file://` page.

## Organized source files

- `index.html`: accessible DOM structure and SVG UI components
- `styles.css`: positioning, holographic styles, animations, responsive layout
- `src/visuals.js`: procedural spaceship, Earth, stars, and seated astronaut SVG scene
- `src/orb.js`: animated transparent WebGL plasma energy orb shader
- `src/audio.js`: explicit user-controlled microphone permission + local volume calculation
- `src/app.js`: UI state, metric detail projections, waveform, keyboard and text demo
- `SKY_SINGLE_FILE.html`: generated version containing all these assets in **one HTML file**
- `SKY_UI_COMPONENT_FUNCTIONAL_SPEC.md`: the detailed feature contract

## Run

```bash
cd sky-ui-demo
python3 -m http.server 8000
# Open http://localhost:8000
```

Or `npx http-server .` if already installed. Node and TypeScript are **not** needed for this browser demo.

## What's functional

- Four metric click targets open accessible details. The metrics are *mock values*, not live telemetry.
- Health hologram, overall status and mission label each open explanatory context.
- Microphone click requests permission; waveform reacts to local input audio; click again to stop; tracks close.
- CSS fallback if WebGL is unavailable; reduced motion is honored by CSS/orb clock.
- Text input triggers a local deterministic reply **only**. No AI model, medical service or speech transcription is connected.
- Escape to close overlays and input; all buttons can be reached by keyboard.

## Visual fidelity limits

The concept image is painterly illustration with non-separable scene layers. This project recreates the composition procedurally and is **not a pixel-perfect copy**. For exact astronaut/window/Earth art, license or create dedicated 3D/background assets; never hide the original flattened screenshot behind transparent UI hotspots.

This is a **design/development prototype**, not a medical or flight-certified system. The `Stable` assessment, ISS day, and all physiological values are fixtures from the image.
